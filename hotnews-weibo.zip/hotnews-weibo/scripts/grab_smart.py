
import requests, re, json, datetime, os, time, random
from bs4 import BeautifulSoup
from openai import OpenAI

client = OpenAI(
    base_url="https://ark.cn-beijing.volces.com/api/v3",
    api_key=os.environ.get("ARK_API_KEY"),
)

today = datetime.date.today().strftime("%Y-%m-%d")
out_path = f"hotnews_weibo_{today}.json"
items = []

# 使用 HotDay API 作为示例源（可更换）
try:
    resp = requests.get("https://www.hotday.uk/api/weibo", timeout=15)
    for entry in resp.json().get("data", [])[:10]:
        title = entry.get("title", "").strip()
        url = entry.get("url", "").strip()

        def get_text(url):
            try:
                html = requests.get(url, timeout=10).text
                soup = BeautifulSoup(html, "html.parser")
                [s.extract() for s in soup(["script", "style"])]
                text = soup.get_text(separator="\n", strip=True)
                if "微博" in text and len(text) > 100:
                    return text[:1000]
            except:
                return None

        content = get_text(url)
        if not content:
            continue

        prompt = f"请根据以下微博内容简要说明发生了什么，包括人物、时间、地点等信息（不需要评论观点）。\n内容：{content}"
        try:
            rsp = client.chat.completions.create(
                model="ep-20250721132115-4hpdj",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.4,
                max_tokens=150
            )
            summary = rsp.choices[0].message.content.strip()
        except:
            summary = title

        items.append({
            "platform": "微博",
            "title": title,
            "link": url,
            "summary": summary,
            "date": today,
            "relevance": "medium",
            "priority": 2
        })
except Exception as e:
    print(f"[Weibo 抓取失败] {e}")

with open(out_path, "w", encoding="utf-8") as f:
    json.dump(items, f, ensure_ascii=False, indent=2)

print(f"✅ 抓取完成，共 {len(items)} 条 → {out_path}")
